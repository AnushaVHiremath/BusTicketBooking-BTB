<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HELP PAGE</title>
    <link rel="stylesheet" href="cssfile/help.css"/>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />


   <style type="text/css">
       body{
        background-image: url(image/4.jpg);
        background-repeat: no-repeat;
        background-size: cover;
        background-attachment: fixed;
       }
   </style>
  
</head>
<body>
  

 
            <!-- body part my entervcode -->

      <div class="wrapper">
        <h2>HELP CENTER</h2>
      <div class="line"><br><br><br><br>
      </div>
      </div>

      <div class="single-service">
            <div class="help">
         <i class="fa fa-search"></i></div>
        <span></span>
             <h3><b>Customer Support<b></h3><br><br>
      <p>
        For Cancellation or Other Queries<br>
        Please Contact : <br><br>0123456789<br>
        9876543210 </p>
      </div>


      <div class="single-service">
            <div class="help">
      <i class="fa fa-headphones"></i></div>
      <span></span>
             <h3><b>More Choices<b></h3><br><br>
      <p>

        We give you maximum choices across<br> all the routes to choose your bus.</p>
      </div>


      
      <div class="single-service">
        <div class="help">
  <i class="fa fa-map-marker"></i></div>
  <span></span>
         <h3><b>Google Map Location<b></h3><br><br>
  <p>
    Google Map Location

    We send you the boarding place and destination<br> place link in google map.
   <br><br>
    (COMING SOON)
     </p>
  </div>

  
 
<script src="js/mystyle.js"></script>


</body>
</html>



