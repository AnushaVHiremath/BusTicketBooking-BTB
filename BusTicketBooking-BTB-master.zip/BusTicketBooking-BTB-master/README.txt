This project is completely developed using HTML,CSS,JS and PHP
All the required HTML, CSS, JS and PHP are available in Repository.
This is a project for booking system where I had developed it for bus ticketing system where user can book, cancel and perform other operations relatedd to bus tickets.
To run the project you need:
Xampp software which is used handle database
Download all the files from this repository. After downloading files place the entire folder in the Xampp/htdocs folder
Now run the Xampp, upload the database which available at the db folder.
note: the name of the database should be same as folder name in xampp/htdocs
now simply run localhost/BusTicketBooking-BTB in your browser
