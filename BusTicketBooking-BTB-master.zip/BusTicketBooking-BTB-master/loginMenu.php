<!DOCTYPE html>
<html>
<head>
	<title>BTB login menu</title>




   <style type="text/css">
   	     
   	     .box{
   	     	width: 500px;
		    height: 250px;
		   /* border: 1px solid black;*/
		    /* align-content: center; */
		    margin: auto;
		    margin-top: 70px;
   	     }
   	     .box1{

   	     	width:500px;
   	     	height: 122px;
   	     	border: 1px solid #fff;
			margin-top:170px;
			margin-bottom:50px;
   	     	background-color: rgba(1,3,0.3,0.5);
   	     	border-radius: 10px;

   	     }
   	     .box2{

   	     	width:500px;
   	     	height: 122px;
   	     	border: 1px solid #fff;
   	     	background-color: rgba(1,3,0.3,0.5);
   	     	border-radius: 10px;
   	     	margin-top: 5px;
   	     }
   	     .box1:hover{

   	     	cursor: pointer;
   	     	background-color: black;
   	     	color: #fff;
   	     }
   	     .box2:hover{
   	     	cursor: pointer;
   	     	background-color: black;
   	     	color: #fff;
   	     }
   	     .loginMenu{
   	     	text-align: center;
   	     	color: #fff;
   	     	font-size: 38px;
   	     }
   	     body{
   	     	background-image: url(image/loginim.jpg);
   	     	background-repeat: no-repeat;
   	     	background-size: cover;
   	     	background-position: center;
   	     	background-attachment: fixed;
   	     }
   	     .menu{

   	     /*	text-transform: uppercase;*/
   	     	color: #fff;
   	     	/*color: #f44336;*/
            text-align: center;
            text-decoration: none;
            margin-top: 43px;

   	     }
   	     .menu:hover{
   	     	color: #f44336;
   	     	font-size: 36px;
   	     }


   </style>

   <link rel="stylesheet" href="cssfile/nav.css">
    <link rel="stylesheet" href="cssfile/footer.css">
 
 <!--
    <link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
  
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
-->


</head>
<body>

	  



<h1 class="loginMenu">LOGIN MENU</h1>

   <div class="box">

      <a href="Login.php">

             <div class="box1">

             	<h1 class="menu">User Login</h1>

             </div>
      </a>

      <a href="adminLogin.php">

             <div class="box2">

             	<h1 class="menu">Admin Login</h1>


             </div>

      </a>



   </div>



</body>
</html>